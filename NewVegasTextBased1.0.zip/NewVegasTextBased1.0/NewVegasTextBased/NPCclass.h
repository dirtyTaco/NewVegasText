#pragma once
#include <time.h>
#include <string>
#include <iostream>
using std::string;
using std::cout;
using std::cin;
using std::endl;

class NPC {
public:
	int damage;
	int armor;
	int maxHealth;
	int currentHealth;
	string name;

	void attacked(string, int, int, int);
};

void NPC::attacked(string pName, int pDam, int hitChance1, int hitChance2) {
	int rando = rand() % 10;

	if (hitChance1 >= 0 && hitChance2 <= 7)
	{
		currentHealth = currentHealth - pDam;
		cout << name << " was hit for " << pDam << " damage!" << endl;
		if (currentHealth <= 0)
			cout << name << " was slain by " << pName << endl;
		else
			cout << name << " has " << currentHealth << " health remaining." << endl;

	}
	else
		cout << pName << " missed!" << endl;

	system("pause");

}