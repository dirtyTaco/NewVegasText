#include "PlayerClass.h"
#include "NPCclass.h"
#include "Items.h"
#include <time.h>

int main() {
	srand(time(NULL));

	char inputC;
	int inputI;

	Player player;
	player.createPlayer();
	player.setSpecial();
	player.setSkills();

	system("CLS");

	//For now, just start the player with pistol equipped, no armor
	weapon pistol;
	pistol.name = "Pistol";
	pistol.dam = 16;
	player.totalDamage = player.RangedBonus + pistol.dam;

	//Very Basic combat sequence vs 2 geckos
	NPC gecko1;
	NPC gecko2;
	gecko1.damage = 10;
	gecko1.currentHealth = 20;
	gecko1.armor = 0;
	gecko1.name = "Gecko";
	gecko2.damage = 10;
	gecko2.currentHealth = 20;
	gecko2.armor = 0;
	gecko2.name = "Gecko";

	player.CurrentHealth = 100;

	cout << "You are ambushed by a couple of Geckos." << endl;
	cout << "Do you want to [F]ight or [R]un? (enter F or R)" << endl;
	cin >> inputC;

	if (inputC == 'F' || inputC == 'f')
	{
		while (gecko1.currentHealth > 0 || gecko2.currentHealth > 0 && player.CurrentHealth > 0)
		{
			system("CLS");

			if (gecko1.currentHealth < 0)
			{
				gecko1.currentHealth = 0;
			}
			else if (gecko2.currentHealth < 0)
			{
				gecko2.currentHealth = 0;
			}

			cout << "Would you like to attack [1]" << gecko1.name << " (HP " << gecko1.currentHealth << ") or [2]" << gecko2.name << " (HP " << gecko2.currentHealth << ")?" << endl;
			cin >> inputI;
			cout << endl;

			if (inputI == 1)
			{
				gecko1.attacked(player.name, player.totalDamage, 0, 7);
			}
			else
			{
				gecko2.attacked(player.name, player.totalDamage, 0, 7);
			}

			if (gecko1.currentHealth > 0)
			{
				cout << endl << "Gecko attacks!" << endl;
				player.attacked(gecko1.name, gecko1.damage, 0, 5);
			}
			
			if (gecko2.currentHealth > 0)
			{
				cout << endl << "Gecko attacks!" << endl;
				player.attacked(gecko2.name, gecko2.damage, 0, 5);
			}
		}

		if (player.CurrentHealth <= 0)
			cout << "You DIED!" << endl;
		else
			cout << "You defeated the Geckos!" << endl;
	}
	else
	{
		system("CLS");

		player.CurrentHealth = player.CurrentHealth - 10;
		cout << "You successfully run from the Geckos but you don't go unscathed! You take 10 damage!" << endl;
	}

	system("pause");
	return 0;
}

