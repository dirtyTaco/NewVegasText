//#pragma once
//#include <iostream>
//#include <string>
//using std::string;
//using std::cout;
//using std::cin;
//using std::endl;
//
//class inventory
//{
//	void addToInventory(string itemType, int itemWeight);
//
//	void displayInventory();
//	void displayWeapons();
//	void displayArmor();
//	void displayConsumables();
//};
//
//class status
//{
//	void generalStatus();
//};