#pragma once
#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::cin;
using std::endl;

//Player Character Class
class Player
{
public:
	//Basic Character Traits (dont affect gameplay)
	string name = "default";
	int age = 0;
	string genderN;//for output
	char gender;//for input
	//Function declaration to set these
	void createPlayer();

	//Level/ Exp
	int level;
	int experience;
	//Function for Leveling up

	//SPECIAL
	int Str = 0;
	int End = 0;
	int Per = 0;
	int Chr = 0;
	int Int = 0;
	int Agi = 0;
	int Luc = 0;

	int setSpecial();
	//SetSPECIAL function declaration^

	//SKILLS (dependant on SPECIAL and chosen TAG skills)
	//Commented out skills may not be necessary
	int speechSkill = 0;
	//int barterSkill = 0;
	int explosivesSkill = 0;
	int rangedSkill = 0;
	//int energyWeaponsSkill = 0;
	//int gunsSkill = 0;
	int lockpickSkill = 0;
	int medicineSkill = 0;
	int meleeWeaponsSkill = 0;
	//int unarmedSkill = 0;
	int repairSkill = 0;
	int scienceSkill = 0;
	int sneakSkill = 0;
	//int survivalSkill = 0;

	int setSkills();
	////Function to set skills^

	//STATS (dependant on SKILLS/SPECIAL)
	int AP = 0;
	int CarriedWeight = 0;
	int CritChance = 0;
	int HealRate = 0; //Health gain per turn outside combat?
	int MaxHealth = 0;
	int MeleeBonus = 0;
	int UnarmedBonus = 0;
	int RangedBonus = 0;
	int totalDamage = 0;
	//int poison, poisonResist
	//int thirst
	//Fatigue? bool for limbs broken?


	//int setStats();
	////Function to set Stats^

	int CarryWeight = 0; // If CarriedWeight > CarryWeight player cannot move?
						 //Need a function to add weight when items added to inventory

	int CurrentHealth = 0;
	int Rads = 0; //Subtracts from health? Debuffs player Stats? Death from Rads?

	int DamResist = 0;
	int RadResist = 0;
	//Equip Armor function to affect these^

	void attacked(string, int, int, int);
};

//Creating a character
void Player::createPlayer() {
	char input = 'n';

	while (input == 'n' || input == 'N') {
		cout << "Are you [M]ale or [F]emale" << endl;
		cin >> gender;

		if (gender == 'M' || gender == 'm')
			genderN = "Male";
		else if (gender == 'F' || gender == 'f')
			genderN = "Female";
		else
			genderN = "Male";

		cout << endl << "What is your name?" << endl;
		cin >> name;

		cout << endl << "How old are you?" << endl;
		cin >> age;


		cout << endl << name << " is a " << age << " year old " << genderN << " from the Mojave wasteland." << endl;
		cout << "Are you sure you want this to be your character? [Y]es or [N]o:" << endl;
		cin >> input;
	}

	system("pause");
}

//Setting SPECIAL function for Character Creation
int Player::setSpecial() {
	//playerinput
	char PI;
	int totalPoints = 40;

	//Player inputs points until totalPoints = 0
	while (totalPoints > 0)
	{
		cout << totalPoints << " SPECIAL points (max 10 points each):" << endl;
		cout << "Press [S] to add one point to strength" << endl << "[P]erception" << endl << "[E]ndurance" << endl << "[C]harisma" << endl << "[I]ntelligence" << endl << "[A]gility" << endl << "[L]uck" << endl << endl;
		cin >> PI;

		if (PI == 's' || PI == 'S')
		{
			if (Str < 11) {
				system("CLS");
				Str = Str + 1;
				cout << "One point added to STRENGTH" << endl;
				totalPoints = totalPoints - 1;
			}
			else
			{
				system("CLS");
				cout << "You already have maximum STRENGTH!" << endl;
			}
		}
		else if (PI == 'p' || PI == 'P')
		{
			if (Per < 11) {
				system("CLS");
				Per = Per + 1;
				cout << "One point added to PERCEPTION" << endl;
				totalPoints = totalPoints - 1;
			}
			else
			{
				system("CLS");
				cout << "You already have maximum PERCEPTION!" << endl;
			}
		}
		else if (PI == 'e' || PI == 'E')
		{
			if (End < 11) {
				system("CLS");
				End = End + 1;
				cout << "One point added to ENDURANCE" << endl;
				totalPoints = totalPoints - 1;
			}
			else
			{
				system("CLS");
				cout << "You already have maximum ENDURANCE!" << endl;
			}
		}
		else if (PI == 'c' || PI == 'C')
		{
			if (Chr < 11) {
				system("CLS");
				Chr = Chr + 1;
				cout << "One point added to CHARISMA" << endl;
				totalPoints = totalPoints - 1;
			}
			else
			{
				system("CLS");
				cout << "You already have maximum CHARISMA!" << endl;
			}
		}
		else if (PI == 'i' || PI == 'I')
		{
			if (Int < 11) {
				system("CLS");
				Int = Int + 1;
				cout << "One point added to INTELLIGENCE" << endl;
				totalPoints = totalPoints - 1;
			}
			else
			{
				system("CLS");
				cout << "You already have maximum INTELLIGENCE!" << endl;
			}
		}
		else if (PI == 'a' || PI == 'A')
		{
			if (Agi < 11) {
				system("CLS");
				Agi = Agi + 1;
				cout << "One point added to AGILITY" << endl;
				totalPoints = totalPoints - 1;
			}
			else
			{
				system("CLS");
				cout << "You already have maximum AGILITY!" << endl;
			}
		}
		else if (PI == 'l' || PI == 'L')
		{
			if (Luc < 11) {
				system("CLS");
				Luc = Luc + 1;
				cout << "One point added to LUCK" << endl;
				totalPoints = totalPoints - 1;
			}
			else
			{
				system("CLS");
				cout << "You already have maximum Luck!" << endl;
			}
		}
		else
		{
			cout << "Invalid choice, please enter one of the following: [S] [P] [E] [C] [I] [A] [L]" << endl;
		}
	}

	//Once all points are input by player, cout the results

	cout << endl << "STRENGTH: " << Str << endl << "PERCEPTION: " << Per << endl << "ENDURANCE: " << End << endl << "CHARISMA: " << Chr << endl << "INTELLIGENCE: " << Int << endl << "AGILITY: " << Agi << endl << "LUCK: " << Luc << endl;
	system("pause");
	system("CLS");

	return Str;
	return End;
	return Per;
	return Chr;
	return Int;
	return Agi;
	return Luc;

}

//Function for setting skills
int Player::setSkills() {
	//for player input
	int PI;
	//for keeping track of how many skills the player can tag (3)
	int tagSkills = 3;
	int choiceNumb = 1;

	//base skills depending on SPECIAL
	speechSkill = Chr * 2;
	rangedSkill = Per + Agi;
	explosivesSkill = Agi * 2;
	lockpickSkill = Per + Int;
	medicineSkill = Int * 2;
	meleeWeaponsSkill = Str * 2;
	repairSkill = Int * 2;
	scienceSkill = Int * 2;
	sneakSkill = Agi * 2;

	//So they can't tag the same skill more than once
	bool speechTagged = false;
	bool rangedTagged = false;
	bool explosivesTagged = false;
	bool lockpickTagged = false;
	bool medicineTagged = false;
	bool meleeTagged = false;
	bool repairTagged = false;
	bool scienceTagged = false;
	bool sneakTagged = false;

	//TAG skills (+15 to 3 skills based on player choice)
	//First we will let the player know their current skills
	cout << "Current Skills:" << endl
		<< "[1]Speech: " << speechSkill << endl
		<< "[2]Ranged: " << rangedSkill << endl
		<< "[3]Explosives: " << explosivesSkill << endl
		<< "[4]Lockpick: " << lockpickSkill << endl
		<< "[5]Medicine: " << medicineSkill << endl
		<< "[6]Melee: " << meleeWeaponsSkill << endl
		<< "[7]Repair: " << repairSkill << endl
		<< "[8]Science: " << scienceSkill << endl
		<< "[9]Sneak: " << sneakSkill << endl;
	//Now we let them make their choices
	cout << "You may TAG any 3 skills, instantly adding 15 points to each!" << endl;
	while (tagSkills > 0) {
		cout << endl << "TAG choice " << choiceNumb << ": ";
		cin >> PI;
		if (PI == 1)
		{
			if (speechTagged == false) {
				cout << "You chose Speech" << endl;
				speechSkill = speechSkill + 15;
				tagSkills = tagSkills - 1;
				choiceNumb = choiceNumb + 1;
				speechTagged = true;
			}
			else
			{
				cout << "You've already tagged SPEECH!" << endl;
			}
		}
		else if (PI == 2)
		{
			if (rangedTagged == false) {
				cout << "You chose Ranged" << endl;
				rangedSkill = rangedSkill + 15;
				tagSkills = tagSkills - 1;
				choiceNumb = choiceNumb + 1;
				rangedTagged = true;
			}
			else
			{
				cout << "You've already tagged RANGED!" << endl;
			}
		}
		else if (PI == 3)
		{
			if (explosivesTagged == false) {
				cout << "You chose Explosives" << endl;
				explosivesSkill = explosivesSkill + 15;
				tagSkills = tagSkills - 1;
				choiceNumb = choiceNumb + 1;
				explosivesTagged = true;
			}
			else
			{
				cout << "You've already tagged EXPLOSIVES!" << endl;
			}
		}
		else if (PI == 4)
		{
			if (lockpickTagged == false) {
				cout << "You chose Lockpick" << endl;
				lockpickSkill = lockpickSkill + 15;
				tagSkills = tagSkills - 1;
				choiceNumb = choiceNumb + 1;
				lockpickTagged = true;
			}
			else
			{
				cout << "You've already tagged LOCKPICK!" << endl;
			}
		}
		else if (PI == 5)
		{
			if (medicineTagged == false) {
				cout << "You chose Medicine" << endl;
				medicineSkill = medicineSkill + 15;
				tagSkills = tagSkills - 1;
				choiceNumb = choiceNumb + 1;
				medicineTagged = true;
			}
			else
			{
				cout << "You've already tagged MEDICINE!" << endl;
			}
		}
		else if (PI == 6)
		{
			if (meleeTagged == false) {
				cout << "You chose Melee" << endl;
				meleeWeaponsSkill = meleeWeaponsSkill + 15;
				tagSkills = tagSkills - 1;
				choiceNumb = choiceNumb + 1;
				meleeTagged = true;
			}
			else
			{
				cout << "You've already tagged MELEE!" << endl;
			}
		}
		else if (PI == 7)
		{
			if (repairTagged == false) {
				cout << "You chose Repair" << endl;
				repairSkill = repairSkill + 15;
				tagSkills = tagSkills - 1;
				choiceNumb = choiceNumb + 1;
				repairTagged = true;
			}
			else
			{
				cout << "You've already tagged REPAIR!" << endl;
			}
		}
		else if (PI == 8)
		{
			if (scienceTagged == false) {
				cout << "You chose Science" << endl;
				scienceSkill = scienceSkill + 15;
				tagSkills = tagSkills - 1;
				choiceNumb = choiceNumb + 1;
				scienceTagged = true;
			}
			else
			{
				cout << "You've already tagged SCIENCE!" << endl;
			}
		}
		else if (PI == 9)
		{
			if (sneakTagged == false) {
				cout << "You chose Sneak" << endl;
				sneakSkill = sneakSkill + 15;
				tagSkills = tagSkills - 1;
				choiceNumb = choiceNumb + 1;
				sneakTagged = true;
			}
			else
			{
				cout << "You've already tagged SNEAK!" << endl;
			}
		}
	}

	system("CLS");
	//Once TAG skills are chosen, output the player's updated skills
	cout << "Current Skills:" << endl
		<< "[1]Speech: " << speechSkill << endl
		<< "[2]Ranged: " << rangedSkill << endl
		<< "[3]Explosives: " << explosivesSkill << endl
		<< "[4]Lockpick: " << lockpickSkill << endl
		<< "[5]Medicine: " << medicineSkill << endl
		<< "[6]Melee: " << meleeWeaponsSkill << endl
		<< "[7]Repair: " << repairSkill << endl
		<< "[8]Science: " << scienceSkill << endl
		<< "[9]Sneak: " << sneakSkill << endl;

	system("pause");


	return speechSkill;
	return rangedSkill;
	return explosivesSkill;
	return lockpickSkill;
	return medicineSkill;
	return meleeWeaponsSkill;
	return repairSkill;
	return scienceSkill;
	return sneakSkill;
}

//Stats function below, not yet implemented

//Function to set Stats based on Skills and SPECIAL
//int Player::setStats() {
//	AP = ; //Based on Agility
//	CarryWeight = ;//Strength
//	CritChance = ;//Luck
//	HealRate = ;//Endurance
//	MaxHealth = ;//Endurance
//	MeleeBonus = ;//Strength, Melee skill
//	UnarmedBonus = ;//Maybe Melee and unarmed can both fit into one stat?
//	RangedBonus = ;//Perception or Agility? and ranged skill

//}

void Player::attacked(string eName, int eDam, int hitChance1, int hitChance2) {
	//For now, just random as to whether or not the player hits
	int rando = rand() % 10;

	if (rando >= hitChance1 && rando <= hitChance2)
	{
		CurrentHealth = CurrentHealth - eDam;
		cout << name << " was hit for " << totalDamage << " damage!" << endl;
		if (CurrentHealth <= 0)
			cout << name << " was slain by " << eName << endl;
		else
			cout << name << " has " << CurrentHealth << " health remaining." << endl;

	}
	else
		cout << eName << " missed!" << endl;

	system("pause");

}
