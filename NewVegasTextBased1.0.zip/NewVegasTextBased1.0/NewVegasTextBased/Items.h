#pragma once
#include <string>
using std::string;

class weapon {
public:
	string description;
	string type;
	string name = "default";

	int dam;

	int ammoCapacity;
	int ammoLoaded;

	int weight;

	int AP;
	//int strReq;
	//int rangedReq;
	
	int value;

	bool isEquipped = false;
	bool equip();

};

class armor {
public:
	string description;
	string type;
	string name;

	int weight;

	int DT;

	int value;


	bool isEquipped = false;
	bool equip();
};

class consumable {
public:
	string description;
	string type;
	string name;

	int value;

	bool isUsed = false;
	bool use();
};


