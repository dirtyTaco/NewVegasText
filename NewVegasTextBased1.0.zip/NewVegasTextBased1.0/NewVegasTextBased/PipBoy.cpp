//#include <iostream>
//#include <string>
//#include "pipBoy.h"
//using std::string;
//using std::cout;
//using std::cin;
//using std::endl;
//
//
//void showPipBoy(string name, int currentHealth, int maxHealth,
//	int currentAP, int maxAP, string armor, string weapon)
//{
//	cout << name << endl << "HP " << currentHealth << " / " << maxHealth << "   AP "
//		<< currentAP << " / " << maxAP << endl << "Armor: " << armor
//		<< "    Weapon: " << weapon << endl
//		<< "____________________________________________________________"
//		<< endl;
//}
//
//void showInventory() {
//	//Displays each category of item (weapons, armor, consumables) and the amount of each type
//	//Player can select a category, shows their items in a list
//	//Player can select each item, view descriptions, stats, equip/use the items
//}
//
//void showStats() {
//	//Player can choose to view their stats/skills/SPECIAL, relations with factions 
//}