#include "Items.h"
#include <iostream>
#include <string>
using std::cout;
using std::cin;
using std::endl;
using std::string;

bool weapon::equip()
{
	char input;

	cout << "Equip " << name << " ? [Y]es or [N]o: " << endl;
	cin >> input;

	if (input == 'y' || input == 'Y')
	{
		isEquipped = true;
		cout << name << "was equipped." << endl;
	}
	else if (input == 'n' || input == 'N')
	{
		isEquipped = false;
		cout << name << "was not equipped." << endl;
	}
	else
	{
		isEquipped = false;
		cout << name << "was not equipped." << endl;
	}

	system("pause");

	return isEquipped;
}


bool armor::equip()
{
	char input;

	cout << "Equip " << name << " ? [Y]es or [N]o: " << endl;
	cin >> input;

	if (input == 'y' || input == 'Y')
	{
		isEquipped = true;
		cout << name << "was equipped." << endl;
	}
	else if (input == 'n' || input == 'N')
	{
		isEquipped = false;
		cout << name << "was not equipped." << endl;
	}
	else
	{
		isEquipped = false;
		cout << name << "was not equipped." << endl;
	}

	system("pause");

	return isEquipped;
}

bool consumable::use()
{
	return false;
}
