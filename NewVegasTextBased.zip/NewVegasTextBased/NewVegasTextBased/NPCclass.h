#pragma once

class NPC {
public:
	int attack;
	int armor;
	int maxHealth;
	int currentHealth;
};