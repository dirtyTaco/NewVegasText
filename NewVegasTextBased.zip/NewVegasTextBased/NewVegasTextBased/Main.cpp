#include "PlayerClass.h"
#include "NPCclass.h"

int main() {
	Player bob;
	bob.createPlayer();
	bob.setSpecial();
	bob.setSkills();
	

	return 0;
}